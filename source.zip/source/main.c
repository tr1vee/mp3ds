/*

#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <tex3ds.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define DR_MP3_IMPLEMENTATION
#include "dr_mp3.h"

#define NUM_BUFFERS 3
#define SAMPLES_PER_BUFFER 1152
#define MAX_FILES 128

static ndspWaveBuf waveBufs[NUM_BUFFERS];
static int16_t* audioBuffers[NUM_BUFFERS];

static drmp3 mp3;
static bool mp3Loaded = false;

char fileList[MAX_FILES][256];
int fileCount = 0;
int selected = 0;

unsigned char* imagedata = NULL;
int imgWidth = 0;
int imgHeight = 0;


C3D_RenderTarget* top;
C3D_RenderTarget* bottom;

C2D_TextBuf g_staticBuf;
C2D_Font font;

C3D_Tex albumTex;
Tex3DS_SubTexture albumSubtex;
bool texReady = false;

bool texLoaded = false;
C2D_SpriteSheet albumSheet;
C2D_Image albumImage;
C2D_SpriteSheet sprites;

C2D_Image bottomImg;
C2D_Image backImg;
C2D_Image playImg;
C2D_Image topImg;
C2D_Image nextImg;
C2D_Image scrollImg;
C2D_Image progressImg;
C2D_Image pauseImg;


typedef struct
{
    char title[128];
    char artist[128];
    char album[128];
} MP3Metadata;

MP3Metadata metadata;

typedef enum
{
    SCREEN_LIBRARY,
    SCREEN_PLAYER,
    SCREEN_DETAILS

} AppScreen;

AppScreen currentScreen = SCREEN_LIBRARY;

void ensure_dir(const char* path)
{
    struct stat st;

    if (stat(path, &st) != 0)
        mkdir(path, 0777);
}

void load_files(const char* path)
{
    DIR* dir = opendir(path);

    if (!dir)
        return;

    struct dirent* entry;

    fileCount = 0;

    while ((entry = readdir(dir)) != NULL && fileCount < MAX_FILES)
    {
        if (entry->d_name[0] == '.')
            continue;

        if (!strstr(entry->d_name, ".mp3"))
            continue;

        snprintf(fileList[fileCount], 256, "%s", entry->d_name);

        fileCount++;
    }

    closedir(dir);
}

void stop_mp3()
{
    if (mp3Loaded)
    {
        drmp3_uninit(&mp3);
        mp3Loaded = false;
    }

    ndspChnReset(0);
}

void start_mp3(const char* path)
{
    stop_mp3();

    if (!drmp3_init_file(&mp3, path, NULL))
    {
        printf("FAILED TO OPEN\n");
        return;
    }

    ndspChnReset(0);

    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, mp3.sampleRate);
    ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);

    for (int i = 0; i < NUM_BUFFERS; i++)
    {
        memset(&waveBufs[i], 0, sizeof(ndspWaveBuf));

        waveBufs[i].data_vaddr = audioBuffers[i];
    }

    mp3Loaded = true;
}

void fill_buffer(int bufIndex)
{
    drmp3_int16 temp[SAMPLES_PER_BUFFER * 2];

    drmp3_uint64 frames =
        drmp3_read_pcm_frames_s16(
            &mp3,
            SAMPLES_PER_BUFFER,
            temp);

    if (frames == 0)
    {
        stop_mp3();
        return;
    }


    DSP_FlushDataCache(
        audioBuffers[bufIndex],
        frames * 2 * sizeof(int16_t));

    waveBufs[bufIndex].nsamples = frames;

    ndspChnWaveBufAdd(0, &waveBufs[bufIndex]);
}

void free_album_art()
{
    if (imagedata)
    {
        stbi_image_free(imagedata);
        imagedata = NULL;
    }
}

void clear_metadata()
{
    memset(&metadata, 0, sizeof(metadata));
}

int syncsafe_to_int(unsigned char* bytes)
{
    return
        ((bytes[0] & 0x7F) << 21) |
        ((bytes[1] & 0x7F) << 14) |
        ((bytes[2] & 0x7F) << 7)  |
        (bytes[3] & 0x7F);
}

void copy_text_frame(
    char* dest,
    int destSize,
    unsigned char* data,
    int frameSize)
{
    if (frameSize <= 1)
        return;

    int len = frameSize - 1;

    if (len >= destSize)
        len = destSize - 1;

    memcpy(dest, data + 1, len);

    dest[len] = '\0';
}

bool load_metadata_and_art(const char* path)
{
    clear_metadata();
    free_album_art();

    FILE* f = fopen(path, "rb");

    if (!f)
        return false;

    unsigned char header[10];

    fread(header, 1, 10, f);

    if (memcmp(header, "ID3", 3) != 0)
    {
        fclose(f);
        return false;
    }

    int tagSize = syncsafe_to_int(&header[6]);

    unsigned char* tagData = malloc(tagSize);

    fread(tagData, 1, tagSize, f);

    fclose(f);

    int pos = 0;

    while (pos < tagSize - 10)
    {
        char frameID[5];

        memcpy(frameID, &tagData[pos], 4);

        frameID[4] = '\0';

        if (frameID[0] == 0)
            break;

        int frameSize =
            (tagData[pos + 4] << 24) |
            (tagData[pos + 5] << 16) |
            (tagData[pos + 6] << 8)  |
            tagData[pos + 7];

        unsigned char* frameData = &tagData[pos + 10];

        if (strcmp(frameID, "TIT2") == 0)
        {
            copy_text_frame(
                metadata.title,
                sizeof(metadata.title),
                frameData,
                frameSize);
        }

        if (strcmp(frameID, "TPE1") == 0)
        {
            copy_text_frame(
                metadata.artist,
                sizeof(metadata.artist),
                frameData,
                frameSize);
        }

        if (strcmp(frameID, "TALB") == 0)
        {
            copy_text_frame(
                metadata.album,
                sizeof(metadata.album),
                frameData,
                frameSize);
        }

        if (strcmp(frameID, "APIC") == 0)
        {
            int imgPos = 0;

            imgPos++;

            while (imgPos < frameSize &&
                   frameData[imgPos] != 0)
            {
                imgPos++;
            }

            imgPos++;
            imgPos++;

            while (imgPos < frameSize &&
                   frameData[imgPos] != 0)
            {
                imgPos++;
            }

            imgPos++;

            int channels;

            imagedata = stbi_load_from_memory(
                &frameData[imgPos],
                frameSize - imgPos,
                &imgWidth,
                &imgHeight,
                &channels,
                4);
        }

        pos += 10 + frameSize;
    }

    free(tagData);

    return true;
}

void upload_album_art()
{
    if (!imagedata)
        return;

    if (texReady)
    {
        C3D_TexDelete(&albumTex);
        texReady = false;
    }

    // create texture
    if (!C3D_TexInit(&albumTex, 512, 512, GPU_RGBA8))
    {
        printf("tex init failed\n");
        return;
    }

    // get texture memory
    u8* dst =
        (u8*)C3D_Tex2DGetImagePtr(
            &albumTex,
            0,
            NULL);

    if (!dst)
    {
        printf("dst null\n");
        return;
    }

    // clamp size
    int copyWidth = imgWidth;
    int copyHeight = imgHeight;

    if (copyWidth > 512)
        copyWidth = 512;

    if (copyHeight > 512)
        copyHeight = 512;

    // clear texture first
    memset(dst, 0, 512 * 512 * 4);

    // copy image
    memcpy(
        dst,
        imagedata,
        copyWidth * copyHeight * 4);

    // flush cache
    GSPGPU_FlushDataCache(
        dst,
        512 * 512 * 4);

    // setup subtexture
    albumSubtex.left = 0.0f;
    albumSubtex.top = 0.0f;
    albumSubtex.right =
        (float)copyWidth / 512.0f;
    albumSubtex.bottom =
        (float)copyHeight / 512.0f;

    albumSubtex.width = copyWidth;
    albumSubtex.height = copyHeight;

    albumImage.tex = &albumTex;
    albumImage.subtex = &albumSubtex;

    texReady = true;

    printf("album uploaded\n");
}


void draw_text(float x, float y, float scale, u32 color, const char* text)
{
    C2D_Text c2dText;

    C2D_TextParse(&c2dText, g_staticBuf, text);
    C2D_TextOptimize(&c2dText);

    C2D_DrawText(
        &c2dText,
        C2D_WithColor,
        x,
        y,
        0.5f,
        scale,
        scale,
        color);
}

void draw_library()
{
    C2D_TargetClear(bottom, C2D_Color32(245,245,245,255));
    C2D_SceneBegin(bottom);

    draw_text(
        90,
        10,
        0.6f,
        C2D_Color32(0,0,0,255),
        "Select a song");

    for (int i = 0; i < fileCount; i++)
    {
        u32 color =
            (i == selected)
            ? C2D_Color32(0,120,255,255)
            : C2D_Color32(0,0,0,255);

        draw_text(
            20,
            40 + (i * 18),
            0.5f,
            color,
            fileList[i]);
    }
}
void draw_album_art()
{
    if (!texReady)
        return;

    C2D_DrawImageAt(
        albumImage,
        20,
        40,
        0.5f,
        NULL,
        0.5f,
        0.5f);
}

void draw_player()
{
    C2D_TargetClear(top, C2D_Color32(255,255,255,255));
    C2D_SceneBegin(top);

    // draw_album_art();

    draw_text(
        170,
        60,
        0.7f,
        C2D_Color32(0,0,0,255),
        metadata.title);

    draw_text(
        170,
        90,
        0.5f,
        C2D_Color32(80,80,80,255),
        metadata.artist);

    draw_text(
        170,
        120,
        0.5f,
        C2D_Color32(120,120,120,255),
        metadata.album);

    C2D_TargetClear(bottom, C2D_Color32(240,240,240,255));
    C2D_SceneBegin(bottom);

    C2D_DrawImageAt(playImg, 135, 90, 0.5f, NULL, 1.0f, 1.0f);
    C2D_DrawImageAt(backImg, 90, 90, 0.5f, NULL, 1.0f, 1.0f);
    C2D_DrawImageAt(nextImg, 180, 90, 0.5f, NULL, 1.0f, 1.0f);
}

int main()
{
   

    gfxInitDefault();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);

    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    sprites = C2D_SpriteSheetLoad("romfs:/gfx/gfx.t3x");
    bottomImg   = C2D_SpriteSheetGetImage(sprites, 0);
    backImg     = C2D_SpriteSheetGetImage(sprites, 1);
    playImg     = C2D_SpriteSheetGetImage(sprites, 2);
    topImg      = C2D_SpriteSheetGetImage(sprites, 3);
    nextImg     = C2D_SpriteSheetGetImage(sprites, 4);
    scrollImg   = C2D_SpriteSheetGetImage(sprites, 5);
    progressImg = C2D_SpriteSheetGetImage(sprites, 6);
    pauseImg    = C2D_SpriteSheetGetImage(sprites, 7);

    top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    g_staticBuf = C2D_TextBufNew(4096);

    ndspInit();
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);

    ensure_dir("sdmc:/MP3DS");
    ensure_dir("sdmc:/MP3DS/music");

    load_files("sdmc:/MP3DS/music");
   
    if (!sprites)
    {
    printf("failed to load sprites\n");
    while (aptMainLoop())
    {
        gspWaitForVBlank();
    }
    }

    for (int i = 0; i < NUM_BUFFERS; i++)
    {
        audioBuffers[i] =
            linearAlloc(
                SAMPLES_PER_BUFFER * 2 * sizeof(int16_t));
    }

    while (aptMainLoop())
    {
        hidScanInput();

        u32 kDown = hidKeysDown();

        if (kDown & KEY_START)
            break;


        if (fileCount > 0)
        {
            if (kDown & KEY_UP)
                selected = (selected - 1 + fileCount) % fileCount;

            if (kDown & KEY_DOWN)
                selected = (selected + 1) % fileCount;
        }


        if (kDown & KEY_B) {
            currentScreen = SCREEN_LIBRARY;
        }

        if ((kDown & KEY_A) && fileCount > 0)
        {
            char path[512];

            snprintf(
                path,
                sizeof(path),
                "sdmc:/MP3DS/music/%s",
                fileList[selected]);

            load_metadata_and_art(path);

                upload_album_art();
           
            

            start_mp3(path);
            currentScreen = SCREEN_PLAYER;

            for (int i = 0; i < NUM_BUFFERS; i++)
                fill_buffer(i);
        }

        if (mp3Loaded)
        {
            for (int i = 0; i < NUM_BUFFERS; i++)
            {
                if (waveBufs[i].status == NDSP_WBUF_DONE)
                {
                    waveBufs[i].status = NDSP_WBUF_FREE;

                    fill_buffer(i);
                }
            }
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

if (currentScreen == SCREEN_LIBRARY)
{
    draw_library();
}

if (currentScreen == SCREEN_PLAYER)
{
    draw_player();
}

C3D_FrameEnd(0);
    }

    stop_mp3();

    free_album_art();

    for (int i = 0; i < NUM_BUFFERS; i++)
        linearFree(audioBuffers[i]);

    C2D_TextBufDelete(g_staticBuf);

    C2D_SpriteSheetFree(sprites);
    C2D_Fini();
    C3D_Fini();

    ndspExit();
    romfsExit();
    gfxExit();

    return 0;
}

*/

#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

#define DR_MP3_IMPLEMENTATION
#include "dr_mp3.h"

#define SAMPLE_RATE 44100
#define SAMPLES_PER_BUFFER 1152
#define NUM_BUFFERS 3
#define MAX_FILES 128

// audio/buffer vars
static ndspWaveBuf waveBufs[NUM_BUFFERS];
static int16_t* audioBuffers[NUM_BUFFERS];

static drmp3 mp3;
static bool mp3Loaded = false;

// file vars
char fileList[MAX_FILES][256];
int fileCount = 0;
int selected = 0;

// directory things
void ensure_dir(const char* path)
{
    struct stat st;
    if (stat(path, &st) != 0)
        mkdir(path, 0777);
}

void load_files(const char* path)
{
    DIR* dir = opendir(path);
    if (!dir) return;

    struct dirent* entry;
    fileCount = 0;

    while ((entry = readdir(dir)) != NULL && fileCount < MAX_FILES)
    {
        if (entry->d_name[0] == '.') continue;

        snprintf(fileList[fileCount], 256, "%s", entry->d_name);
        fileCount++;
    }

    closedir(dir);
}

// did you really need a comment ro understand what stop_mp3() did?
void stop_mp3()
{
    if (mp3Loaded)
    {
        drmp3_uninit(&mp3);
        mp3Loaded = false;
    }
}


int main()
{
    gfxInitDefault();
    ndspInit();

    ndspSetOutputMode(NDSP_OUTPUT_STEREO);

    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, SAMPLE_RATE);
    ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);

    consoleInit(GFX_TOP, NULL);

    // folders
    ensure_dir("sdmc:/MP3DS");
    ensure_dir("sdmc:/MP3DS/music");

    load_files("sdmc:/MP3DS/music");

    printf("MP3DS PLAYER\nA=Play  START=Exit\n\n");

    // init buffers
    for (int i = 0; i < NUM_BUFFERS; i++)
    {
        audioBuffers[i] =
            (int16_t*)linearAlloc(SAMPLES_PER_BUFFER * 2 * sizeof(int16_t));

        memset(&waveBufs[i], 0, sizeof(ndspWaveBuf));

        waveBufs[i].data_vaddr = audioBuffers[i];
        waveBufs[i].nsamples = SAMPLES_PER_BUFFER;
        waveBufs[i].looping = false;
    }

    // make loop
    while (aptMainLoop())
    {
        hidScanInput();
        u32 kDown = hidKeysDown();

        if (kDown & KEY_START)
            break;

        // navigation
        if (kDown & KEY_UP)
        {
            if (--selected < 0) selected = fileCount - 1;
        }

        if (kDown & KEY_DOWN)
        {
            selected = (selected + 1) % fileCount;
        }

        // actually make noise from the file
        if (kDown & KEY_A && fileCount > 0)
        {
            char path[512];
            snprintf(path, sizeof(path),
                "sdmc:/MP3DS/music/%s",
                fileList[selected]);

            printf("Loading:\n%s\n", path);

            stop_mp3();

            if (!drmp3_init_file(&mp3, path, NULL))
            {
                printf("FAILED TO OPEN\n");
                continue;
            }

            mp3Loaded = true;
        }

        // stream the audio
        if (mp3Loaded)
        {
            for (int b = 0; b < NUM_BUFFERS; b++)
            {
                if (waveBufs[b].status == NDSP_WBUF_FREE)
                {
                    drmp3_int16 temp[SAMPLES_PER_BUFFER * 2];

                    drmp3_uint64 frames =
                        drmp3_read_pcm_frames_s16(
                            &mp3,
                            SAMPLES_PER_BUFFER,
                            temp);

                    if (frames == 0)
                    {
                        stop_mp3();
                        break;
                    }

                    for (int i = 0; i < frames * 2; i++)
                        audioBuffers[b][i] = temp[i];

                    DSP_FlushDataCache(
                        audioBuffers[b],
                        SAMPLES_PER_BUFFER * 2 * sizeof(int16_t));

                    waveBufs[b].nsamples = frames;

                    ndspChnWaveBufAdd(0, &waveBufs[b]);
                }
            }
        }

        // the "ui"
        consoleClear();
        printf("MP3DS PLAYER\n\n");

        for (int i = 0; i < fileCount; i++)
        {
            if (i == selected)
                printf("> %s\n", fileList[i]);
            else
                printf("  %s\n", fileList[i]);
        }

        gspWaitForVBlank();
    }

    // cleanup
    stop_mp3();

    for (int i = 0; i < NUM_BUFFERS; i++)
        linearFree(audioBuffers[i]);

    ndspExit();
    gfxExit();

    return 0;
}